

************************************************************************************************************************
************************************************************************************************************************
* HIGH THREAT ENVIRONMENTS AND ALLIANCES AMONG MILITANT GROUPS OF DISSIMILAR IDEOLOGIES
************************************************************************************************************************
************************************************************************************************************************

************************************
************************************
*load data
************************************
************************************

use "C:\Users\chris\Dropbox\Research\Militant Group Alliances\Final data for sharing\highthreatenvironments.dta", clear




************************************
*MODEL 1: Dissimilar allies (no controls)
************************************

*Model;
#delimit;
logit dissimilarallies v2x_clphy conflict enemysamestate    peaceyrs* if year > 1949 & year < 2014 , robust cl(group1);

*Export model;
		#delimit;
		outreg2 using "C:\Users\Chris\OneDrive\Desktop\Results\model1.xls", 
		alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
		e(all)  excel replace;

*Sample;
gen sample1 = e(sample);

*Summarize;
sum dissimilarallies v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc if sample1==1;
	
	
************************************
*MODEL 2: Dissimilar allies (full model)
************************************	

*Model;
#delimit;
logit dissimilarallies v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peaceyrs* if year > 1949 & year < 2014, robust cl(group1);

*Export model;
		#delimit;
		outreg2 using "C:\Users\Chris\OneDrive\Desktop\Results\model2.xls", 
		alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
		e(all)  excel replace;


*calculate substantive effects	
listcoef, percent help;


*calculate VIF
collin v2x_clphy conflict enemysamestate   outbidding stateallies ethfrac rugged xm wbpop wbgdppc  ;



*clear splines 
#delimit;
drop peaceyrs*;
drop _spline*;



************************************
*MODEL 3: Dissimilar operations support (no controls)
************************************	

*generate new polynomials for operations support
#delimit;
btscs  dissimilaropsupport year group1, g(peaceyrs) nspline(3);
gen peaceyrs3 = peaceyrs*peaceyrs*peaceyrs;
gen peaceyrs2 = peaceyrs*peaceyrs;



*Model;
#delimit;
logit dissimilaropsupport v2x_clphy conflict enemysamestate   peaceyrs* if year > 1949 & year < 2014, robust cl(group1);

*Export model;
		#delimit;
		outreg2 using "C:\Users\Chris\OneDrive\Desktop\Results\model3.xls", 
		alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
		e(all)  excel replace;
		

		
************************************
*MODEL 4: Dissimilar operations support (full model)
************************************		

*Model
#delimit;	
logit dissimilaropsupport v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc peaceyrs* if year > 1949 & year < 2014, robust cl(group1);

*Export model
		#delimit;
		outreg2 using "C:\Users\Chris\OneDrive\Desktop\Results\model4.xls", 
		alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
		e(all)  excel replace;
		

*generate sample ID
gen sample4 = e(sample)
	
*Calculate substantive effects
listcoef, percent help


************************************	
*SIMULATIONS
************************************	

*generate predictions from Model 4 and then list observations to identify cases
predict p
	
	*organize data
	order p
	
	*sort data
	sort ccode group1_id year
	
	*sort by p	
	gsort- p
				
	*list groups by p
list group1 ccode p if dissimilaropsupport==1 & p !=.

*list groups by key IVs if they are at risk for war
list group1 ccode year p v2x_clphy conflict enemysamestate outbidding if dissimilaropsupport==1 & p !=. & v2x_clphy <.5   & conflict==1 & enemysamestate==1 & outbidding >=1

*detail groups with no risk
tab group1_id year if p==0

*summarize variables from model 4
sum dissimilarallies v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc if sample4==1
	

*** PKK - 1981 (1781)  
list ccode year v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc peace* if ccode==640 & year == 1981 & group1==1781
margins, at((mean) _all v2x_clphy= .063    conflict=0 enemysamestate=1  outbidding=30 stateallies=6 ethfrac=.24885783     rugged= 2.62    xm=-.35095151      wbpop=17.593   wbgdppc=9.057   peaceyrs=0 peaceyrs2=0 peaceyrs3=0)  level(95) saving(file1, replace)


*** MNLF - 1983 (2040)
list ccode year v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc peace* if ccode==840 & year == 1983 & group1==2040
margins, at((mean) _all v2x_clphy=.066  conflict=1 enemysamestate=1  outbidding=5 stateallies=0 ethfrac=.82973044   rugged=2.028    xm=-.17602397      wbpop=17.734    wbgdppc=8.3 peaceyrs=0 peaceyrs2=0 peaceyrs3=0 )  level(95) saving(file2, replace)


*** Turkish Hizballah - 1995 (3180)
list ccode year v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peace*  if ccode==640 & year == 1995 & group1==3180
margins, at((mean) _all v2x_clphy=.066  conflict=1 enemysamestate=1  outbidding=6 stateallies=0 ethfrac=.82973044   rugged=2.028    xm=-.0888592     wbpop=17.795  wbgdppc=8.193 peaceyrs=0 peaceyrs2=0 peaceyrs3=0 ) level(95) saving(file3, replace)


*** IRA - 1950 (1443)
list ccode year v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peace*  if ccode==200 & year == 1950 & group1==1443
sum v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peace* if group1==3180 & sample4==1
margins, at((mean) _all v2x_clphy=.86  conflict=0 enemysamestate=0  outbidding=1 stateallies=0 ethfrac= .30862604      rugged=.568     xm=  9.367        wbpop=17.795  wbgdppc= 9.367 peaceyrs= 28   peaceyrs2= 784 peaceyrs3=21952 ) level(95) saving(file4, replace)

*** MB - 1995 (2128)
list ccode year v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peace*  if ccode==640 & group1==3180 
sum v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peace* if group1==3180  & sample4==1 & ccode==640
margins, at((mean) _all v2x_clphy=.4117568  conflict=1 enemysamestate=0  outbidding=29.75676 stateallies=.8918919  ethfrac=.3781101    rugged= 2.62   xm=.8583195      wbpop= 17.89042   wbgdppc= 9.463361 peaceyrs=2.972973   peaceyrs2= 23.2973  peaceyrs3=227.0811 ) level(95) saving(file5, replace)


*** SSNP - 1995 (3040)
list ccode year v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peace*  if ccode==660 & group1==3040
sum v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peace* if group1==3040  & sample4==1
margins, at((mean) _all v2x_clphy=.6345529    conflict=0 enemysamestate=0  outbidding= 9.717647  stateallies=0 ethfrac= .1283096    rugged= 4.197    xm=  .4407911     wbpop= 14.73034   wbgdppc=8.836243 peaceyrs= 42   peaceyrs2=  2366    peaceyrs3=149940 ) level(95) saving(file6, replace)


***Avg organization
sum v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peace* if sample4==1
margins, at( v2x_clphy=.4873048   conflict=0 enemysamestate=0  outbidding= 13.24728  stateallies=0 ethfrac=.4522159     rugged=1.601796     xm=.5665812      wbpop=17.06892    wbgdppc=8.782751 peaceyrs=12.77449   peaceyrs2=362.1596    peaceyrs3=15167.99  ) level(95) saving(file7, replace)


*Create figure 1
combomarginsplot file1 file2 file3 file4 file5 file6 file7, recast(scatter) plotopts(msiz(small) mc(gs4)) ciopts(lw(medthick)) horizontal ///
  labels("PKK" "MNLF" "Turkish Hizballah"  "IRA" "Muslim Brotherhood" "SSNP" "Average Group") xline(0)  xtitle("") xtitle("Predicted Probability of Dissimilar Operation Support") ytitle("") title("") scheme(s1mono)
graph export "C:\Users\chris\Dropbox\Research\Militant Group Alliances\figure1.png", as(png) name("Graph")
  
  
  

  
************************************		 
*LEVERAGE PLOTS
************************************
	 
**********
**re-run Model 2
**********  
logit dissimilarallies v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peaceyrs* if year > 1949 & year < 2014, robust cl(group1)

*identify sample
gen sampleA2 = e(sample)

*Identify outliers
gen uniqueid = _n if sampleA2==1
predict p
predict hat, hat
predict dbeta, dbeta


*Plot outliers
sum hat
scatter hat p if sampleA2==1,  scheme(s1mono) xtitle("Pr(Dissimilar Alliance)") yline(.4) ytitle("Leverage")  
	graph export "C:\Users\chris\Dropbox\Research\Militant Group Alliances\leverage2.tif",replace

	
*run analysis with outliers removed
  logit dissimilarallies v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc  peaceyrs* if year > 1949 & year < 2014 & hat <= .4, robust cl(group1)
  
*Export model;
		#delimit;
		outreg2 using "C:\Users\Chris\Desktop\Results\modelA1.xls", 
		alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
		e(all)  excel replace;

*clean data
  drop p hat dbeta
  
  
********** 
**re-run Model  4
**********

logit dissimilaropsupport v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc peaceyrs* if year > 1949 & year < 2014 , robust cl(group1)

*identify sample
gen sampleA4 = e(sample)


*Identify outliers
predict p
predict hat, hat
predict dbeta, dbeta

  
*Plot outliers
sum hat
scatter hat p if sampleA4==1,  scheme(s1mono) xtitle("Pr(Dissimilar Operations Support)") yline(.2)  ytitle("Leverage")  
  	graph export "C:\Users\chris\Dropbox\Research\Militant Group Alliances\leverage4.tif",replace


*run analysis with outliers removed 
logit dissimilaropsupport v2x_clphy conflict enemysamestate  outbidding stateallies ethfrac rugged xm wbpop wbgdppc peaceyrs* if year > 1949 & year < 2014 & hat <=.2, robust cl(group1)

*Export model;
		#delimit;
		outreg2 using "C:\Users\Chris\Desktop\Results\modelA2.xls", 
		alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
		e(all)  excel replace;
  
  
  
  





	

	
	
	