
log using "C:\Users\chris\Dropbox\Interventions\Submissions\JOGSS\Final draft\logfile-jogss.txt", text replace





******************************************************************************************************************************************************
******************************************************************************************************************************************************
******************************************************************************************************************************************************
******************************************************************************************************************************************************
* PLAYING THE ETHNIC CARD
*
* Ben Jones and Chris Linebarger
*
* December 15, 2020
*
* Journal of Global Security Studies
*
******************************************************************************************************************************************************
******************************************************************************************************************************************************
******************************************************************************************************************************************************
******************************************************************************************************************************************************

*load data
use "C:\Users\chris\Dropbox\Interventions\Data\playing the ethnic card - JOGSS - 12-15-2020.dta", clear


#delimit;


****************************************************************************************************;
****************************************************************************************************;
* ANALYSIS;
****************************************************************************************************;
****************************************************************************************************;



**************************************************;
* BIVARIATE MODELS;
**************************************************;

logit rebintonset_miss l_leaderexits  tm* if ethdom2==1 , robust cl(dyadid_ep);
est sto ex1;

logit rebintonset_miss l_cumirr  tm* if ethdom2==1 , robust cl(dyadid_ep);
est sto cumirr1;

logit rebintonset_miss l_cumirrpost  tm* if ethdom2==1 , robust cl(dyadid_ep);
est sto cumirrpos1;

logit rebintonset_miss l_revrsgovstability  tm* if ethdom2==1 &  year > 1989, robust cl(dyadid_ep);
est sto govsta1;

logit rebintonset_miss l_revrssocio  tm* if ethdom2==1 &  year > 1989 , robust cl(dyadid_ep);
est sto sociosta1;

estout ex1 cumirr1 cumirrpos1 govsta1 sociosta1, ///
	cells( b(fmt(3) star ) se(fmt(3) nostar par  ) ) ///
	starlevel(+ 0.1 * 0.05 ** 0.01 *** 0.001) ///
	stats(N ll aic, fmt(0 3 3 3 3) pc(@) ) ///
	order(l_leaderexits l_cumirr l_cumirrpost l_revrsgovstability l_revrssocio tm*) ///
	noabb sty(tex) ;

	
	
***************************************************************************;
* MULTIVARIATE MODELS;
***************************************************************************;

*************************;
* MODEL 6;
*************************;


logit rebintonset_miss c.l_leaderexits l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l  l1.cum_rebintonset  tm* if ethdom2==1 , robust cl(dyadid_ep);
est sto ex2;

gen sample1 = e(sample);




*************************;
* MODEL 7;
*************************;

logit rebintonset_miss c.l_cumirr l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset  tm* if ethdom2==1 , robust cl(dyadid_ep);
est sto cumirr2;

gen sample2 = e(sample);

	
*marginal effects and figure;
	
margins, predict(pr) at(l_cumirr=(0(1)8));

#delimit
label variable l_cumirr "Cumulative Irregular Leader Exits";
marginsplot ,  title("") recastci(rarea) plot1opts(msymbol(none) lp(dash) lw(thick)) ci1opts(fintensity(40)) scheme(s1mono) xlabel(0(1)35) ytitle("XXX") addplot(histogram l_cumirr if sample2==1, percent yaxis(2) yscale(alt) ytitle("Dubious") fcolor(%15)  ytitle("XXX")
legend(order(1 "95% Confidence interval" 2 "Pr(Rebel Support Onset)" 3 "Cumulative Irregular Leader Exits") col(1) ))	;


*graph export "C:\Users\chris\Dropbox\Interventions\Text\model7.pdf", as(pdf) name("Graph") replace
;

*************************;
* MODEL 8;
*************************;

logit rebintonset_miss c.l_cumirrpost l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset  tm* if ethdom2==1 , robust cl(dyadid_ep);
est sto cumirrpost2;

gen sample3 = e(sample);


	
*marginal effects and figure;
#delimit;
margins , predict(pr) at(l_cumirrpost=(0(1)6));

#delimit;
marginsplot ,  title("") recastci(rarea) plot1opts(msymbol(none) lp(dash) lw(thick)) ci1opts(fintensity(40)) scheme(s1mono) xlabel(0(1)6) ytitle("XXX") addplot(histogram l_cumirrpost if sample3==1, percent yaxis(2) yscale(alt) ytitle("Dubious") fcolor(%15)  ytitle("Pr(Wall construction)")
legend(order(1 "95% Confidence interval" 2 "Pr(Rebel Support Onset)" 3 "Cumulative Irregular Post Tenure Fates") col(1) ))	;
	
#delimit;		
*graph export "C:\Users\chris\Dropbox\Interventions\Text\model8.pdf", as(pdf) name("Graph") replace
;	
	
	
*************************;
* MODEL 9;
*************************;

logit rebintonset_miss c.l_revrsgovstability l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset  tm* if ethdom2==1 & year > 1989, robust cl(dyadid_ep);
est sto govsta2;

gen sample4 = e(sample);
	

	
*marginal effects and figure;
#delimit;	
margins, predict(pr) at(l_revrsgovstability=(0(1)11));

#delimit;
marginsplot ,  title("") recastci(rarea) plot1opts(msymbol(none) lp(dash) lw(thick)) ci1opts(fintensity(40)) scheme(s1mono) xlabel(0(1)12) ytitle("XXX") addplot(histogram l_revrsgovstability if sample4==1, percent yaxis(2) yscale(alt) ytitle("Dubious") fcolor(%15)  ytitle("Pr(Wall construction)")
legend(order(1 "95% Confidence interval" 2 "Pr(Rebel Support Onset)" 3 "Cumulative Irregular Post Tenure Fates") col(1) ))	;
	
#delimit;		
*graph export "C:\Users\chris\Dropbox\Interventions\Text\model9.pdf", as(pdf) name("Graph") replace
;	
	

*************************;
*calculating substantive effects of model 9, discussed in paper (-1 std dev to +1 std dev);
*************************;

#delimit;
sum c.l_revrsgovstability l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset if sample4==1;
logit rebintonset_miss l_revrsgovstability l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1  & year > 1989, robust cl(dyadid_ep);

margins, predict(pr) at(l_revrsgovstability=1.74191 l_jtdem=1  l_cinc_3_100=1.836618 l_cinc_100= 1.446735 l_defense=0 l_smoothtotrade_l=3.410071  l_cum_rebintonset=4.253 )  ;
margins, predict(pr) at(l_revrsgovstability=6.201526 l_jtdem=1  l_cinc_3_100=1.836618 l_cinc_100= 1.446735 l_defense=0 l_smoothtotrade_l=3.410071  l_cum_rebintonset=4.253 )    ;

margins, predict(pr) at(l_govint_any=1 l_revrsgovstability=4.0 l_jtdem=1  l_cinc_3_100=1.836618 l_cinc_100= 1.446735 l_defense=0 l_smoothtotrade_l=3.410071  l_cum_rebintonset=4.253 )  ;  
margins, predict(pr) at(l_govint_any=2 l_revrsgovstability=4.0  l_jtdem=1  l_cinc_3_100=1.836618 l_cinc_100= 1.446735 l_defense=0 l_smoothtotrade_l=3.410071  l_cum_rebintonset=4.253 ) ;

margins, predict(pr) at(l_cinc_100 = 1.39 l_revrsgovstability=4.0  l_jtdem=1  l_cinc_3_100=1.836618  l_defense=0 l_smoothtotrade_l=3.410071  l_cum_rebintonset=4.253 )    ;
margins, predict(pr) at(l_cinc_100  = 5.5 l_revrsgovstability=4.0  l_jtdem=1  l_cinc_3_100=1.836618 l_defense=0 l_smoothtotrade_l=3.410071  l_cum_rebintonset=4.253 )   ;

	
*************************;
*Russia simulation	discussed in paper;
*************************;

#delimit;
logit rebintonset_miss c.l_revrsgovstability l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1 & year > 1989 & gwnoa_3 != 365, robust cl(dyadid_ep);
sum c.l_revrsgovstability l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l tm* if gwnoa_3 == 365 & ethdom2 == 1;

*-1 STD to +1 STD;
#delimit;	
margins, predict(pr) at(l_revrsgovstability=(1.18989 6.661962) l1.govint_any==1 l1.jtdem=0 l1.cinc_100=0.4358477 l1.cinc_3_100 = 12.12797 l1.defense=0 l1.smoothtotrade_l=3.569  l_cum_rebintonset=7.103896 (mean) tm tm2 tm3);
    
*Russia 2014;
#delimit;
margins, predict(pr) at(l_revrsgovstability=(3.8) l1.govint_any==1 l1.jtdem=0 l1.cinc_100=0.4358477 l1.cinc_3_100 = 12.12797 l1.defense=0 l1.smoothtotrade_l=3.569 (mean) tm tm2 tm3);

*Russia 2004;
margins, predict(pr) at(l_revrsgovstability=(.7) l1.govint_any==1 l1.jtdem=0 l1.cinc_100=0.4358477 l1.cinc_3_100 = 12.12797 l1.defense=0 l1.smoothtotrade_l=3.569 (mean) tm tm2 tm3);


					
*************************;
* MODEL 10;
*************************;
logit rebintonset_miss c.l_revrssocio l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l  l1.cum_rebintonset tm* if ethdom2==1 & year > 1989, robust cl(dyadid_ep);
est sto sociosta2;

gen sample5 = e(sample);



*marginal effects and figure;	
#delimit;	
margins, predict(pr) at(l_revrssocio=(0(1)11));

#delimit;
marginsplot ,  title("") recastci(rarea) plot1opts(msymbol(none) lp(dash) lw(thick)) ci1opts(fintensity(40)) scheme(s1mono) xlabel(0(1)12) ytitle("XXX") addplot(histogram l_revrssocio if sample5==1, percent yaxis(2) yscale(alt) ytitle("Dubious") fcolor(%15)  ytitle("Pr(Wall construction)")
legend(order(1 "95% Confidence interval" 2 "Pr(Rebel Support Onset)" 3 "Cumulative Irregular Post Tenure Fates") col(1) ))	;
		
#delimit;		
*graph export "C:\Users\chris\Dropbox\Interventions\Text\model10.pdf", as(pdf) name("Graph") replace
;	
		

*Create table 2		
estout ex2 cumirr2 cumirrpost2 govsta2 sociosta2, ///
	cells( b(fmt(3) star ) se(fmt(3) nostar par  ) ) ///
	starlevel(+ 0.1 * 0.05 ** 0.01 *** 0.001) ///
	stats(N ll aic, fmt(0 3 3 3 3) pc(@) ) ///
	order(l_leaderexits l_cumirr l_cumirrpost l_revrsgovstability l_revrssocio ///
	l.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l  l1.cum_rebintonset  tm*) ///
	noabb sty(tex) 	;	
	

	
	
	
	
	
***************************************************************************;
* DESCRIPTVE STATISTICS;
***************************************************************************;
		
sum rebintonset_miss l_leaderexits l_cumirr l_cumirrpost l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l  l_cum_rebintonset  tm* if ethdom2==1;
estpost summarize rebintonset_miss l_leaderexits l_cumirr l_cumirrpost l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm*  if ethdom2==1  ;
esttab, varlabels(`e(labels)') cells(" mean sd min max") tex;

estpost summarize l_revrsgovstability l_revrssocio  if ethdom2==1  & year > 1989;
esttab, varlabels(`e(labels)') cells(" mean sd min max") tex;







***************************************************************************;
* MODEL DIAGNOSTICS;
***************************************************************************;

*************************;
*Check VIF and Tolerance	;
*************************;

*Check VIF and Tolerance	;
#delimit;
	collin  l_leaderexits l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if   sample1==1 ;	
	collin  l_cumirr l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if   sample2==1 ;	
	collin  l_cumirrpost l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if   sample3==1 ;	
	collin  l_revrsgovstability l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if   sample4==1 ;	
	collin  l_revrssocio l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if   sample5==1 ;	

	
	
*************************;
*check for influential observations ;
*************************;
	
*M6

#delimit;
logit rebintonset_miss l_leaderexits l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1, robust cl(dyadid_ep);
	#delimit;
		gen id=_n;
		predict hat, hat;
		predict p;
		scatter hat p,  yline(0.2) ytitle(Leverage, size(vlarge)) xtitle(Pr(Rebel Support Onset), size(vlarge)) scheme(s1mono);
			*graph export "~/Dropbox/Interventions/Text/leverage1-revised.pdf", as(pdf) replace;

		
	*repeat  with influencial obs removed;
		#delimit;
		logit rebintonset_miss l_leaderexits l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1 & hat < .2, robust cl(dyadid_ep);
			est sto out1;
			/*outreg2 using "C:\Users\Chris\OneDrive\Desktop\robust1.xls", 
			alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
			e(all)  excel replace;
*/
			drop id hat p	;
			
*M7
#delimit;	
logit rebintonset_miss l_cumirr l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1, robust cl(dyadid_ep);
	#delimit;
		gen id=_n;
		predict hat, hat;
		predict p;
		scatter hat p,  yline(0.2) ytitle(Leverage, size(vlarge)) xtitle(Pr(Rebel Support Onset), size(vlarge)) scheme(s1mono);
			*graph export "~/Dropbox/Interventions/Text/leverage2-revised.pdf", as(pdf) replace;
		
	*repeat  with influencial obs removed;
		#delimit;
		logit rebintonset_miss l_cumirr l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1 & hat < .2, robust cl(dyadid_ep);
				est sto out2;
				drop id hat p;	
						
			/*outreg2 using "C:\Users\Chris\OneDrive\Desktop\robust2.xls", 
			alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
			e(all)  excel replace;
			*/

			
			
*M8	
#delimit;			
logit rebintonset_miss l_cumirrpost l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1, robust cl(dyadid_ep);
	#delimit;
		gen id=_n;
		predict hat, hat;
		predict p;
		scatter hat p,  yline(0.2) ytitle(Leverage, size(vlarge)) xtitle(Pr(Rebel Support Onset), size(vlarge)) scheme(s1mono);
			*graph export "~/Dropbox/Interventions/Text/leverage3-revised.pdf", as(pdf) replace;
		
	*repeat  with influencial obs removed;
		#delimit;


		logit rebintonset_miss l_cumirrpost l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1 & hat < .2, robust cl(dyadid_ep);
					est sto out3;
					drop id hat p;	
						
			/*outreg2 using "C:\Users\Chris\OneDrive\Desktop\robust3.xls", 
			alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
			e(all)  excel replace;
			*/
			
*M9		
#delimit;			
logit rebintonset_miss l_revrsgovstability l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1  & year > 1989, robust cl(dyadid_ep);
	#delimit;
		gen id=_n;
		predict hat, hat;
		predict p;
		scatter hat p,  yline(0.2) ytitle(Leverage, size(vlarge)) xtitle(Pr(Rebel Support Onset), size(vlarge)) scheme(s1mono);
			*graph export "~/Dropbox/Interventions/Text/leverage4-revised.pdf", as(pdf) replace;

	*repeat  with influencial obs removed;
		#delimit;
		logit rebintonset_miss l_revrsgovstability l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1 & hat < .2, robust cl(dyadid_ep);
					est sto out4;
					drop id hat p;	
			/*outreg2 using "C:\Users\Chris\OneDrive\Desktop\robust4.xls", 
			alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
			e(all)  excel replace;
			*/
	

*M10
#delimit;	
logit rebintonset_miss l_revrssocio l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1  & year > 1989, robust cl(dyadid_ep);
	#delimit;
		gen id=_n;
		predict hat, hat;
		predict p;
		scatter hat p,  yline(0.2) ytitle(Leverage, size(vlarge)) xtitle(Pr(Rebel Support Onset), size(vlarge)) scheme(s1mono);
			*graph export "~/Dropbox/Interventions/Text/leverage5-revised.pdf", as(pdf) replace;

	*repeat  with influencial obs removed;
		#delimit;
		logit rebintonset_miss l_revrssocio l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1 & hat < .2, robust cl(dyadid_ep);
			/* outreg2 using "C:\Users\Chris\OneDrive\Desktop\robust5.xls", 
			alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
			e(all)  excel replace;
			*/
			*weirdly this is costa rica-US that is driving this????
			list gwnoa gwnoa_3 year l_revrssocio hat if hat > .2 & hat != .; 
			est sto out5;
			drop id hat p;	
	
*Create table 6		;
estout out1 out2 out3 out4 out5, ///
	cells( b(fmt(3) star ) se(fmt(3) nostar par  ) ) ///
	starlevel(+ 0.1 * 0.05 ** 0.01 *** 0.001) ///
	stats(N ll aic, fmt(0 3 3 3 3) pc(@) ) ///
	order(l_leaderexits l_cumirr l_cumirrpost l_revrsgovstability l_revrssocio ///
	l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm*) ///
	noabb sty(tex) 		;
		
	
	
	


***************************************************************************;
* ALTERNATIVE SPECIFICATIONS;
***************************************************************************;

	#delimit;

*************************;
* MODELS WITH OBJECTIVE MEASURES OF INSTABILITY AND GDP ;
*************************;
gen lninstability = ln(instability+1);
gen lngdp_growth = ln(gdp_growth+1);

*Instability;
logit rebintonset_miss l1.lninstability l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1  , robust cl(dyadid_ep);
			est sto instab;
			
*Growth
logit rebintonset_miss l1.lngdp_growth l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l_cum_rebintonset tm* if ethdom2==1  , robust cl(dyadid_ep);
			est sto grow ;
			
			
			
*Create table ;	
estout instab grow, ///
	cells( b(fmt(3) star ) se(fmt(3) nostar par  ) ) ///
	starlevel(+ 0.1 * 0.05 ** 0.01 *** 0.001) ///
	stats(N ll aic, fmt(0 3 3 3 3) pc(@) ) ///
	order(l1. lninstability l1.lngdp_growth  ///
	l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l tm*) ///
	noabb sty(tex) 				;



*************************;
* MODELS INCLUDING OBSERVATIONS AFTER AN ONSET (IE, MISSING OBSERVATIONS);
*************************;

logit rebintonset  l_leaderexits l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset  pys* if ethdom2==1 , robust cl(dyadid_ep);
			est sto alt1;

logit rebintonset  l_cumirr l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset  pys* if ethdom2==1 , robust cl(dyadid_ep);
			est sto alt2;

logit rebintonset  l_cumirrpost l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset  pys* if ethdom2==1  , robust cl(dyadid_ep);
			est sto alt3;

logit rebintonset  l_revrsgovstability l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset pys* if year > 1989 & ethdom2==1 , robust cl(dyadid_ep);
			est sto alt4;

logit rebintonset  l_revrssocio l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset pys* if year > 1989 & ethdom2==1, robust cl(dyadid_ep);
			est sto alt5;

*Create table 	
estout alt*, ///
	cells( b(fmt(3) star ) se(fmt(3) nostar par  ) ) ///
	starlevel(+ 0.1 * 0.05 ** 0.01 *** 0.001) ///
	stats(N ll aic, fmt(0 3 3 3 3) pc(@) ) ///
	order(l_leaderexits l_cumirr l_cumirrpost l_revrsgovstability l_revrssocio ///
	l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm*) ///
	noabb sty(tex) 		;
		
	
	
	
*************************;
* MODELS WITH ALTERNATE CLUSTERING;
*************************;

logit rebintonset_miss c.l_leaderexits l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l  l1.cum_rebintonset  tm* if ethdom2==1 , robust cl(dyadid);
			est sto altcluster1;

logit rebintonset_miss c.l_cumirr l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset  tm* if ethdom2==1 , robust cl(dyadid);
			est sto altcluster2;

logit rebintonset_miss c.l_cumirrpost l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset  tm* if ethdom2==1 , robust cl(dyadid);
			est sto altcluster3;

logit rebintonset_miss c.l_revrsgovstability l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset  tm* if ethdom2==1 & year > 1989, robust cl(dyadid);
			est sto altcluster4;
			
logit rebintonset_miss c.l_revrssocio l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l  l1.cum_rebintonset tm* if ethdom2==1 & year > 1989, robust cl(dyadid);
			est sto altcluster5;


*Create table 	
estout altcluster*, ///
	cells( b(fmt(3) star ) se(fmt(3) nostar par  ) ) ///
	starlevel(+ 0.1 * 0.05 ** 0.01 *** 0.001) ///
	stats(N ll aic, fmt(0 3 3 3 3) pc(@) ) ///
	order(l_leaderexits l_cumirr l_cumirrpost l_revrsgovstability l_revrssocio ///
	l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm*) ///
	noabb sty(tex) 		;
		
	



*************************;
* INTERACTION MODELS;
*************************;


logit rebintonset_miss c.l_leaderexits##i.l1.ethdom2 l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset tm*, robust cl(dyadid_ep);
			est sto int1;

logit rebintonset_miss c.l_cumirr##i.l1.ethdom2 l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset tm* , robust cl(dyadid_ep);
			est sto int2;

logit rebintonset_miss c.l_cumirrpost##i.l1.ethdom2 l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset   tm*  , robust cl(dyadid_ep);
			est sto int3;

logit rebintonset_miss c.l_revrsgovstability##i.l1.ethdom2 l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset tm* if year > 1989, robust cl(dyadid_ep);
			est sto int4;

logit rebintonset_miss c.l_revrssocio##i.l1.ethdom2 l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset tm* if year > 1989, robust cl(dyadid_ep);
			est sto int5;

*Create table 	
estout int*, ///
	cells( b(fmt(3) star ) se(fmt(3) nostar par  ) ) ///
	starlevel(+ 0.1 * 0.05 ** 0.01 *** 0.001) ///
	stats(N ll aic, fmt(0 3 3 3 3) pc(@) ) ///
	order(l_leaderexits l_cumirr l_cumirrpost l_revrsgovstability l_revrssocio ///
	l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm*) ///
	noabb sty(tex) 		;
		
	
	
*marginal effects and figure for Model 9;
#delimit;	
logit rebintonset_miss c.l_revrsgovstability##i.l1.ethdom2 l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset tm* if year > 1989, robust cl(dyadid_ep);
gen sample_int = e(sample);

#delimit;		
	predict p;
	label variable l_revrsgovstability "Government Instability";
	#delimit;
		graph twoway 
		(histogram l_revrsgovstability if sample_int==1,  ysize(3) xsize(4) percent scheme(s1mono)  yaxis(1)  ytitle("Percentage of Observations",size(medlarge) 		axis(1)))
		(lfitci p  l_revrsgovstability if sample_int==1 & l1.ethdom2==0, lcolor(gs2) lpattern(dash dot) yaxis(2) clwidth(thick) ytitle("", 	size(medlarge) axis(2)) )  
		(lfitci p  l_revrsgovstability if sample_int==1 & l1.ethdom2==1, lcolor(gs2)  xtitle(, size(medlarge)) yaxis(2) clwidth(thick) ytitle("Pr(Rebel Support Onset)", 		size(medlarge) axis(2)) 
		),
		legend(order(5 "EGIP/MEG=1" 3 "EGIP/MEG=0" 2 "95% CI" 1 "Government Instability") col(1) ); 
	*graph export "C:\Users\chris\Dropbox\Interventions\Text\interaction.tif", as(tif) width(2000)  replace ;
drop p;





*************************;
* MODELS WITHOUT TROOPS
*************************

*recalculate counters for these models;
btscs rebintonset_miss year dyadid_ep, g(tmnotroops);
gen tmnotroops2 = tmnotroops*tmnotroops;
gen tmnotroops3 = tmnotroops*tmnotroops*tmnotroops;

*which observations and countries contain pro-rebel troop deployments?;
tab rebint_troop if ethdom2==1 ;
tab gwnoa_3 if rebint_troop ==1 & ethdom2==1;

logit rebintonset_miss c.l_leaderexits l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l  l1.cum_rebintonset  tmnotroops* if ethdom2==1 & rebint_troop==0, robust cl(dyadid_ep);
			est sto troops1;

logit rebintonset_miss c.l_cumirr l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset  tmnotroops* if ethdom2==1 & rebint_troop==0, robust cl(dyadid_ep);
			est sto troops2;

logit rebintonset_miss c.l_cumirrpost l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset  tmnotroops* if ethdom2==1 & rebint_troop==0, robust cl(dyadid_ep);
			est sto troops3;
			
logit rebintonset_miss c.l_revrsgovstability l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l l1.cum_rebintonset  tmnotroops* if ethdom2==1 & year > 1989 & rebint_troop==0, robust cl(dyadid_ep);
			est sto troops4;
			
logit rebintonset_miss c.l_revrssocio l1.govint_any  l1.jtdem  l1.cinc_100 l1.cinc_3_100 l1.defense l1.smoothtotrade_l  l1.cum_rebintonset tmnotroops* if ethdom2==1 & year > 1989 & rebint_troop==0, robust cl(dyadid_ep);
			est sto troops5;



*Create table ;	
estout troops*, ///
	cells( b(fmt(3) star ) se(fmt(3) nostar par  ) ) ///
	starlevel(+ 0.1 * 0.05 ** 0.01 *** 0.001) ///
	stats(N ll aic, fmt(0 3 3 3 3) pc(@) ) ///
	order(l_leaderexits l_cumirr l_cumirrpost l_revrsgovstability l_revrssocio ///
	l_govint_any  l_jtdem  l_cinc_100 l_cinc_3_100 l_defense l_smoothtotrade_l l_cum_rebintonset tm*) ///
	noabb sty(tex) ;		
		
	
clear;
 
log close;
 
 
 