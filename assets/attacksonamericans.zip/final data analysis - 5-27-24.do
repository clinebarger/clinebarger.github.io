
	 
***************************************************************************************************************************************
***************************************************************************************************************************************
***************************************************************************************************************************************
* ANALYSIS
***************************************************************************************************************************************
***************************************************************************************************************************************
***************************************************************************************************************************************


	
******************************************************************************************	
******************************************************************************************
* CHAPTER 5 ANALYSIS 
******************************************************************************************
******************************************************************************************	 
	
************
*set working directory
************
cd "~\Dropbox\Attacks on Americans Book Project\1.Data\"

	
************
* OPEN DATA
************

use "analysisdata.dta", clear
	 
************
* XTSET 
************
	 
xtset torg year




************
* DESCRIPTIVES
************	
	
xtdescribe


sum total_us_attacks outhb inhb
	
tab total_us_attacks
tab outhb
tab inhb





************
* CROSS TABS
************	

*attacks on Americans and ideology
tab usattackbinary RELI
tab usattackbinary LEFT


	
*attacks outside homebase and religious
tab outhbbinary RELI
tab outhbbinary LEFT




	
	
	
	
	
	
	
************************
************************
* MODEL 1: All attacks
************************	
************************	
	
logit usattackbinary l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time attackyears*  ,  robust cl(torg)	
	est sto m1
	gen sample1 = e(sample)
	
outreg2  using "Chapter5OutLogit1",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace
		
		listcoef, percent help

	
	
	
************************
************************
* MODEL 2: All attacks sans IRQ and AFG
************************	
************************	
	
	
logit usattackbinary l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time attackyears*  if hbccode !=700 & hbccode !=645 ,  robust cl(torg)	
	est sto m2
	gen sample2 = e(sample)
	
	
outreg2  using "Chapter5OutLogit2",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace
		  
		listcoef, percent help

	
	
	
	
	
	
	
	
	
************************
************************
* MODEL 3: Outside Homebase Attacks
************************	
************************	
	
	
	
	
	
	
	
logit outhbbinary l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp   l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time outhbyears*  ,  robust cl(torg)	
	est sto m3
	gen sample3 = e(sample)
	
outreg2  using "Chapter5OutLogit3",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace
		  
		listcoef, percent help

		  
	

	
************************
************************
* MODEL 4: Outside Homebase Attacks sans IRQ and AFG
************************	
************************	
	
	
		
	
logit outhbbinary l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp   l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time outhbyears*  if hbccode !=700 & hbccode !=645,  robust cl(torg)	
		est sto m4
		gen sample4 = e(sample)
	
outreg2  using "Chapter5OutLogit4",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace

		listcoef, percent help
	
	
	
	
	
	
	
	
	
************************
************************
* MODEL 5: Inside Homebase Attacks
************************	
************************	
	
	
	
logit inhbbinary l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp l1.RELI l1.LEFT l1.SEPA  l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time inhbyears*  ,  robust cl(torg)	
	est sto m5
	gen sample5 = e(sample)
	
	
	
outreg2  using "Chapter5OutLogit5",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace

		listcoef, percent help
	
	
	
	
	
	

	
************************
************************
* MODEL 6: Inside Homebase Attacks sans IRQ and AFG
************************	
************************	
	
		
	
	
	
	
logit inhbbinary l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp l1.RELI l1.LEFT l1.SEPA  l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time inhbyears*   if hbccode !=700 & hbccode !=645,  robust cl(torg)	
	est sto m6
	gen sample6 = e(sample)
	
	
	
outreg2  using "Chapter5OutLogit6",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace

		listcoef, percent help
	
	
	
	
	
************************
************************
* MODEL 7: Full negbinom model
************************	
************************
	
***NEG BINOM
nbreg total_us_attacks l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.total_us_attacks  , irr robust cl(torg)
	est sto m7
	gen sample7 = e(sample)
	
outreg2  using "Chapter5NegBinM7",  alpha(0.001, 0.01, 0.05, 0.1) eform e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace
		  

		  
		  
	
************************
************************
* MODEL 8: Negbinom without AFG or IRQ
************************	
************************
	
		  
***NEG BINOM
nbreg total_us_attacks l1.lnustroops  l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.total_us_attacks  if hbccode !=700 & hbccode !=645, irr robust cl(torg)
	est sto m8
	gen sample8 = e(sample)
	
		  

outreg2  using "Chapter5NegBinM8",  alpha(0.001, 0.01, 0.05, 0.1) eform e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace
		  		  
		  

		  
		  
		  
		 
	
************************
************************
* MODEL 9: Full negbinom model outside homebase
************************	
************************
	
***NEG BINOM
nbreg outhb l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.outhb  , irr robust cl(torg)
	est sto m9
	gen sample9 = e(sample)
	
outreg2  using "Chapter5NegBinM9",  alpha(0.001, 0.01, 0.05, 0.1) eform e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace
		  
 
		  
		  
		  
		
	
************************
************************
* MODEL 10: Full negbinom model outside homebase -- IRQ and AFG excluded
************************	
************************  
		  
		  
		  	
***NEG BINOM
nbreg outhb l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp   l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.outhb  if hbccode !=700 & hbccode !=645 , irr robust cl(torg)
	est sto m10
	gen sample10 = e(sample)
	
outreg2  using "Chapter5NegBinM10",  alpha(0.001, 0.01, 0.05, 0.1) eform e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace
		  
 
		  
		  
	
	
************************
************************
* MODEL 11: Full negbinom model inside homebase
************************	
************************	  
		  
		  
***NEG BINOM
nbreg inhb l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.inhb  , irr robust cl(torg)
	est sto m11
	gen sample11 = e(sample)
	
outreg2  using "Chapter5NegBinM11",  alpha(0.001, 0.01, 0.05, 0.1) eform e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace
		  
		  
		  
		  
	
************************
************************
* MODEL 12: Full negbinom model inside homebase --- IRQ and AFG excluded.
************************	
************************	  	  
		  
***NEG BINOM
nbreg inhb l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.inhb if hbccode !=700 & hbccode !=645  , irr robust cl(torg)
	est sto m12
	gen sample12 = e(sample)
	
outreg2  using "Chapter5NegBinM12",  alpha(0.001, 0.01, 0.05, 0.1) eform e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace
		  
		  
		  
		  
		  
		  
******************************************************************************************	
******************************************************************************************
*CHAPTER 5 APPENDIX
******************************************************************************************	
******************************************************************************************		  

*********************
*DESCRIPTIVE STATS
*********************

sum usattackbinary inhbbinary outhbbinary inhb outhb  total_us_attacks lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time if sample1==1

outreg2  using "dstats", replace sum(log) keep(usattackbinary inhbbinary outhbbinary inhb outhb  total_us_attacks lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time) word

 

*********************
*Outlier diagnostics 
*********************

***********
***********
*Model 1
***********
***********

logit usattackbinary lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time attackyears*  ,  robust cl(torg)

	gen sampleA1 = e(sample)

*Identify outliers
gen uniqueid = _n if sampleA1==1
predict p
predict hat, hat
predict dbeta, dbeta




*Plot outliers
sum hat
scatter hat p if sampleA1==1,  scheme(s1mono) xtitle("Pr(Attack on Americans)") yline(.1) ytitle("Leverage")  
	graph export "C:\Users\chris\Dropbox\Attacks on Americans Book Project\5. DRAFTS _Chapters\CHAPTER 5\leverage1.tif",replace


*list outliers
list hbccode HBASE year ORG RELI hat year  if hat>= .1 & sampleA1 ==1


*recompute with outliers removed 
logit usattackbinary lag_tpaid lag_usaid lag_lnustroops lag_fdstate lag_lngdp  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time attackyears*  if hat <= .1 ,  robust cl(torg)


outreg2  using "Chapter5OutLogit1Appendix",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace

drop unique p dbeta uniqueid hat


***********
***********
*Model 3
***********
***********

logit outhbbinary lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp  lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time outhbyears*  ,  robust cl(torg)


	gen sampleA2 = e(sample)

*Identify outliers
gen uniqueid = _n if sampleA2==1
predict p
predict hat, hat
predict dbeta, dbeta


*Plot outliers
sum hat
scatter hat p if sampleA2==1,  scheme(s1mono) xtitle("Pr(Attack on Americans)") yline(.1) ytitle("Leverage")  
	graph export "C:\Users\chris\Dropbox\Attacks on Americans Book Project\5. DRAFTS _Chapters\CHAPTER 5\leverage2.tif",replace



*list outliers
list hbccode HBASE year ORG RELI hat year  if hat>= .1 & sampleA2 ==1


*recompute with outliers removed 
logit outhbbinary lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp  lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time outhbyears*   if hat <= .1 ,  robust cl(torg)


outreg2  using "Chapter5OutLogit2Appendix",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace

	
	drop unique p dbeta uniqueid hat

	
***********
***********
*Model 5
***********
***********
	
logit inhbbinary lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time inhbyears*  ,  robust cl(torg)

	gen sampleA3 = e(sample)

*Identify outliers
gen uniqueid = _n if sampleA3==1
predict p
predict hat, hat
predict dbeta, dbeta


*Plot outliers
sum hat
scatter hat p if sampleA3==1,  scheme(s1mono) xtitle("Pr(Attack on Americans)") yline(.1) ytitle("Leverage")  
	graph export "C:\Users\chris\Dropbox\Attacks on Americans Book Project\5. DRAFTS _Chapters\CHAPTER 5\leverage3.tif",replace



*list outliers
list hbccode HBASE year ORG RELI hat year  if hat>= .1 & sampleA3 ==1



*recompute with outliers removed 
logit inhbbinary lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time inhbyears*   if hat <= .1  ,  robust cl(torg)


outreg2  using "Chapter5OutLogit3Appendix",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, *, +) bdec(4) sdec(4) word replace



	drop unique p dbeta uniqueid hat

	





	
	
	
	
*********************
*VIF diagnostics 
*********************

*Model 1
collin    lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time	if   sample1==1 


*Model 3
collin    lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time	if   sample3==1 

	
*Model 5
collin    lag_lnustroops lag_tpaid lag_usaid lag_fdstate lag_lngdp  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time	if   sample5==1 

	
	
	
	


************************************************************
************************************************************
*CHAPTER 6 ANALYSIS
************************************************************
************************************************************

****************
*set up data for analysis
****************

*gen lnattacks
gen lnattacks = ln(total_us_attacks+1)

*PREP DATA FOR HAZARD ANALYSIS
bysort torg (year) : gen yearcount=[_n] // sort data
by torg (year),sort: egen lastspellend= max(cond(yearcount,year,.)) // generate spells
gen groupend = 1 if lastspellend == year  // flag end of spell
replace groupend = 0 if groupend==. // deal with missing end of spell data
replace groupend = 0 if lastspell==2012 // code last year of data as group continuing to live
stset yearcount, fail(groupend==1) exit(lastspell) id(torg) // stset the data


*organize the stset data
order _st _d _t _t0 yearcount lastspell groupend

*Nelson Aalen cumu hazard
sts graph , by(usattackbinary) na scheme(s1mono) title("") ytitle("Cumulative Hazard", size(medlarge))  xtitle("Time in Years", size(medlarge))  plot1opts(lc(gs0) lp(dash) lw(thick)) plot2opts(lc(gs0) lp(line) lw(thick))  legend(order( 1 "Insurgent Group Never Attacks Americans" 2 "Insurgent Groups Attacks At Least 1 American") col(1) )
		graph export "C:\Users\chris\Dropbox\Research\Book Project\nelson.jpg", as(jpg) name("Graph") width(2000) replace

*Kaplan Meier curve
sts graph, by(usattackbinary) scheme(s1mono) title("") ytitle("Survival Function", size(medlarge))  xtitle("Time in Years", size(medlarge))  plot1opts(lc(gs0) lp(dash) lw(thick)) plot2opts(lc(gs0) lp(line) lw(thick))  legend(order( 1 "Insurgent Group Never Attacks Americans" 2 "Insurgent Groups Attacks At Least 1 American") col(1) )
		graph export "C:\Users\chris\Dropbox\Research\Book Project\km.jpg", as(jpg) name("Graph") width(2000) replace



******************************************
* COX MODELS
******************************************

**********
*MODEL 1
**********

*model
stcox total troops tpaid usaid fdstate lngdp  RELI LEFT SEPA  TERR  COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time  ,   nolog robust cluster(torg)  schoenfeld(sch*) scaledsch(sca*)		


	*PH TEST
		stphtest, detail
		drop sch* sca*
		
	
				*export model
				#delimit;
				outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab1-M1-may2024", 
				e(N N_sub N_fail N_compete N_censor ll chi2 ) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se) 
				eform   
				bdec(4) 
				sdec(4) 
				excel 
				replace;

	
		*store needed data
		gen sample1 = e(sample)
		est sto cox1
	
	
	



**********		
*FIGURE 6.3 --- SURVIVAL CURVE;
**********

#delimit;
stcurve , survival at(total_us_attacks =(0 5))
lp(dash solid ) 
lwidth(thick thick ) 
lc(gs0 gs0 )  
xtitle("Time in Years", size(medlarge))  
legend(order( 1 "Insurgent Group Never Attacks Americans"
			2 "Insurgent Group Commits Any Number of Attacks on Americans" ) 
		col(1))  
scheme(s1mono) 
title("") 
ytitle("Survival Function", size(medlarge));
		graph export "C:\Users\chris\Dropbox\Attacks on Americans Book Project\1.Data\survivalfunction.jpg", as(jpg) name("Graph") width(2000) replace



**********
*MODEL 2
**********
*model
stcox total troops tpaid usaid fdstate lngdp  RELI LEFT SEPA TERRCNTRL   COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time  if hbccode !=700 & hbccode !=645 ,   nolog robust cluster(torg)	schoenfeld(sch*) scaledsch(sca*)	

	gen sample2 = e(sample)
	
	*PH TEST
		stphtest, detail	
		drop sch* sca*	
	
	*corrected model	
	stcox total troops tpaid usaid fdstate lngdp  RELI LEFT SEPA TERRCNTRL   COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time  if hbccode !=700 & hbccode !=645 ,tvc(troops RELI SEPA)    	nolog 		robust cluster(torg) 		
		est sto cox2
				
				*export model
				#delimit;
				outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab1-M2-may2024", 
				e(N N_sub N_fail N_compete N_censor ll chi2 ) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se) 
				eform   
				bdec(4) 
				sdec(4) 
				excel 
				replace;
 		
	
*show the impact of jihadist groups on the religious variable
tab ORG if sample2==1 & RELI==1
	
	
	
	
	
	
**********
*MODEL 3
**********

*model
stcox outhb troops tpaid usaid fdstate lngdp  RELI LEFT SEPA TERRCNTRL   COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time  ,   nolog robust cluster(torg) schoenfeld(sch*) scaledsch(sca*)		
	
	*PH TEST
		stphtest, detail
		drop sch* sca*
		
		

				*export model
				#delimit;
				outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab2-M3-may2024", 
				e(N N_sub N_fail N_compete N_censor ll chi2 ) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se) 
				eform   
				bdec(4) 
				sdec(4) 
				excel 
				replace;
 		
		
	

**********
*MODEL 4
**********
		
		
*model
stcox outhb  troops tpaid usaid fdstate lngdp  RELI LEFT SEPA TERRCNTRL   COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time   if hbccode !=700 & hbccode !=645 ,   nolog robust cluster(torg) schoenfeld(sch*) scaledsch(sca*)		
	
	*PH TEST
		stphtest, detail
		drop sch* sca*
		
		*corrected for PH
		stcox outhb  troops tpaid usaid fdstate lngdp  RELI LEFT SEPA TERRCNTRL   COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time   if hbccode !=700 & hbccode !=645 , tvc(troops RELI SEPA)   nolog robust cluster(torg) 
		
				*export model
				#delimit;
				outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab2-M4-may2024", 
				e(N N_sub N_fail N_compete N_censor ll chi2 ) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se) 
				eform   
				bdec(4) 
				sdec(4) 
				excel 
				replace;
 		
	
**********
*MODEL 5
**********	
		
*model
stcox inhb  troops tpaid usaid fdstate lngdp  RELI LEFT SEPA TERRCNTRL   COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time  ,   nolog robust cluster(torg) schoenfeld(sch*) scaledsch(sca*)		
	*PH TEST
		stphtest, detail
		drop sch* sca*
		
			*export model
				#delimit;
				outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab2-M5-may2024", 
				e(N N_sub N_fail N_compete N_censor ll chi2 ) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se) 
				eform   
				bdec(4) 
				sdec(4) 
				excel 
				replace;	
			
		
		
		
		

**********
*MODEL 6
**********			

*model	
stcox inhb  troops tpaid usaid fdstate lngdp  RELI LEFT SEPA TERRCNTRL   COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time if hbccode !=700 & hbccode !=645  ,   nolog robust cluster(torg) schoenfeld(sch*) scaledsch(sca*)		

	*PH TEST
		stphtest, detail
		drop sch* sca*		
		
		*PH correction
		stcox inhb  troops tpaid usaid fdstate lngdp  RELI LEFT SEPA TERRCNTRL   COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time if hbccode !=700 & hbccode !=645  , tvc(troops RELI SEPA)   nolog robust cluster(torg) 	

		*export model
				#delimit;
				outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab2-M6-may2024", 
				e(N N_sub N_fail N_compete N_censor ll chi2 ) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se) 
				eform   
				bdec(4) 
				sdec(4) 
				excel 
				replace;	
			
			
		
		
****************************************					
*Additional Analysis for Chapter 6
****************************************					

*which groups attacking americans die within the sample?
list  ORG total_ lastspellend if total_ >0 & total_ !=.	 & lastspellend < 2012	
	
* which groups attack Americans outside the homebase?
list  ORG total_ lastspellend if outhb >0 & outhb !=.
		
		*do they die? no, they don't.
		list  ORG total_ lastspellend if outhb >0 & outhb !=.	 & lastspellend < 2012	

		
* no groups attacking inside dies
list  ORG total_ lastspellend if inhb >0 & inhb !=.	

	*do they die? no, they don't, except the GAM.	
	list  ORG total_ lastspellend if inhb >0 & inhb !=.	 & lastspellend < 2012	

	

*********************************************	
* code below allows us to see which groups ever, during their lifecycle, attacked inside or outside their homebase (Table X, Chapter 5)
*********************************************

*****	
*outside homebase attacks
*****
*gen time of attacks
by torg, sort: egen firsttime = min(cond(outhbbinary == 1, year, .))
replace firsttime = . if outhbbinary==.

gen firsttimedummy = 1 if firsttime !=.
replace firsttimedummy = 0 if firsttimedummy==.
replace firsttimedummy =. if  outhbbinary==.

order firsttime

gen time = 1 if firsttime == year
order time outhbbinary
bysort torg (year): carryforward time, replace
replace time = 0 if time==.
replace time = . if outhbbinary==.

*gen treatment
gen treatment = .
order treatment
replace treatment = 1 if time	==1
gen negyear = -year
bysort  torg (negyear): carryforward treatment, replace
sort torg year
replace treatment = 0 if treatment==.
replace treatment = . if outhbbinary==.

*****
*inside homebase attacks
*****
*gen time of attacks
by torg, sort: egen firsttimeIN = min(cond(inhbbinary == 1, year, .))
replace firsttimeIN = . if inhbbinary==.

gen firsttimedummyIN = 1 if firsttimeIN !=.
replace firsttimedummyIN = 0 if firsttimedummyIN==.
replace firsttimedummyIN =. if  inhbbinary==.

order firsttimeIN

gen timeIN = 1 if firsttimeIN == year
order timeIN inhbbinary
bysort torg (year): carryforward timeIN, replace
replace timeIN = 0 if timeIN==.
replace timeIN = . if inhbbinary==.

*gen treatment
gen treatmentIN = .
order treatmentIN
replace treatmentIN = 1 if time	==1
gen negyearIN = -year
bysort  torg (negyear): carryforward treatmentIN, replace
sort torg year
replace treatmentIN = 0 if treatmentIN==.
replace treatmentIN = . if inhbbinary==.

*Cross Tab reported in Chapter 5
tab firsttimedummy firsttimedummyIN


**********		
*Hazard Ratio Plots	
**********			
label variable usattackbinary "Attacks on Americans"		
label variable lnustroops "US Troops (ln)"		
label variable fdstate "State Sponsor"		
label variable lngdppc "GDPpc (ln)"		
label variable RELI "Religious"		
label variable LEFT "Left-wing"		
label variable SEPA "Separatist"		
label variable TERRCNTRL "Territory"		
label variable COUNT_ALLIES "Allies"		
label variable COUNT_RIVALS "Rivals"		
label variable exports1 "Exports to US"		
label variable imports1 "Imports from US"		
label variable mcdonalds_time "Time Since Introduction of McDonalds"		

gen separatistXtime = SEPA*ln(_t)
label variable separatistXtime "Separatist * ln(Time)"
		
*coefplot of M1 and M2
	stcox usattackbinary lnustroops fdstate lngdp  RELI LEFT SEPA  separatistXtime TERRCNTRL   COUNT_ALLIES COUNT_RIVALS exports1 imports1 mcdonalds_time   ,  	nolog 		robust cluster(torg)	
		

coefplot cox1 cox2, scheme(s1mono) xline(1) eform levels(90) grid(none) legend(order(1 "90% Confidence Interval" 2 "Model 1" 4 "Model 2") col(1) )
	graph export "C:\Users\chris\Dropbox\Research\Book Project\CoxAttack1.jpg", as(jpg) name("Graph") width(2000) replace
	

	
	
	
	
	
	
	
	
	

****************************************
****************************************
* LETHALITY MODELS
****************************************
****************************************		
	
	
*********************
* Set up models 
*********************
	
	
*gen time of attacks
by torg, sort: egen firsttime = min(cond(usattackbinary == 1, year, .))
replace firsttime = . if total_us_attacks==.

gen firsttimedummy = 1 if firsttime !=.
replace firsttimedummy = 0 if firsttimedummy==.
replace firsttimedummy =. if  total_us_attacks==.

order firsttime

gen time = 1 if firsttime == year
order time total_us_attacks
bysort torg (year): carryforward time, replace
replace time = 0 if time==.
replace time = . if total_us_attacks==.

*gen treatment
gen treatment = .
order treatment
replace treatment = 1 if time	==1
gen negyear = -year
bysort  torg (negyear): carryforward treatment, replace
sort torg year
replace treatment = 0 if treatment==.
replace treatment = . if total_us_attacks==.


*gen firt attack indicator
gen yearfirstattack = .
replace yearfirstattack = year if year==firsttime

*gen counter after first attack
tsspell, cond(time == 1)
drop _spell _end
rename _seq counter

	
replace SIZE = . if SIZE == -99
gen lnfatal = ln(FATALITIES+1)
	
	
	
*Descriptive statistics
sum FATALITIES
	
	
hist FATALITIES ,  xtitle(Fatalities, size(medlarge)) ytitle(Observations, size(medlarge))  freq scheme(s1mono) 	
		graph export "C:\Users\chris\Dropbox\Research\Book Project\histogram-fatalities.jpg", as(jpg) name("Graph") width(2000) replace

	
	
**********
*MODEL 8
**********	

*lethality model	
nbreg FATALITIES  time counter l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.FATALITIES   , irr robust cl(torg)

	
		*export model
		#delimit;
		outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab3-M8.xls", 
				e(N r2 adjr2  df_r) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se)  
				eform
				bdec(4) 
				sdec(4) 
				excel 
				replace;
		
	
*complete model, then without irq and afg
*out model, then without outliers
*in model, then without outliers

*6 models total	
	
	
	
**********
*MODEL 9
**********	
	
*lethality model, sans IRQ and AFG	
nbreg FATALITIES  time counter l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.FATALITIES if hbccode !=700 & hbccode !=645   , irr robust cl(torg)

		*export model
		#delimit;
		outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab3-M9.xls", 
				e(N r2 adjr2  df_r) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se)    
				eform
				bdec(4) 
				sdec(4) 
				excel 
				replace;
		
	
	

	
*********************
* Set up models of attacks outside homebase
*********************
	

*gen time of attacks
by torg, sort: egen outfirsttime = min(cond( outhbbinary == 1, year, .))
replace outfirsttime = . if total_us_attacks==.

gen outfirsttimedummy = 1 if outfirsttime !=.
replace outfirsttimedummy = 0 if outfirsttimedummy==.
replace outfirsttimedummy =. if  total_us_attacks==.

order outfirsttime

gen outtime = 1 if outfirsttime == year
order outtime total_us_attacks
bysort torg (year): carryforward outtime, replace
replace outtime = 0 if outtime==.
replace outtime = . if total_us_attacks==.


*gen out treatment
gen outtreatment = .
order outtreatment
replace outtreatment = 1 if outtime	==1
drop negyear
gen negyear = -year
bysort  torg (negyear): carryforward outtreatment, replace
sort torg year
replace outtreatment = 0 if outtreatment==.
replace outtreatment = . if total_us_attacks==.


*gen counter after first attack
tsspell, cond(outtime == 1)
drop _spell _end
rename _seq outcounter

	
	
	
**********
*MODEL 10
**********	

*lethality model
nbreg FATALITIES  outtime outcounter l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.FATALITIES  ,  irr robust cl(torg)	

		*export model
		#delimit;
		outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab3-M10.xls", 
				e(N r2 adjr2  df_r) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se)    
				eform
				bdec(4) 
				sdec(4) 
				excel 
				replace;
	
	
	
**********
*MODEL 11
**********	

*lethality model, sans IRQ and AFG	
nbreg FATALITIES  outtime outcounter l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.FATALITIES  if hbccode !=700 & hbccode !=645 ,  irr robust cl(torg)	

		*export model
		#delimit;
		outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab3-M11.xls", 
				e(N r2 adjr2  df_r) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se)  
				eform
				bdec(4) 
				sdec(4) 
				excel 
				replace;
	
	
	
	
	

	
*********************
* Set up models of attacks INSIDE homebase
*********************
	
	
*try as above, but with hbin
*gen time of attacks
by torg, sort: egen infirsttime = min(cond( inhbbinary == 1, year, .))
replace infirsttime = . if total_us_attacks==.

gen infirsttimedummy = 1 if infirsttime !=.
replace infirsttimedummy = 0 if infirsttimedummy==.
replace infirsttimedummy =. if  total_us_attacks==.

order infirsttime

gen intime = 1 if infirsttime == year
order intime total_us_attacks
bysort torg (year): carryforward intime, replace
replace intime = 0 if intime==.
replace intime = . if total_us_attacks==.


*gen in treatment
gen intreatment = .
order intreatment
replace intreatment = 1 if intime	==1
drop negyear
gen negyear = -year
bysort  torg (negyear): carryforward intreatment, replace
sort torg year
replace intreatment = 0 if intreatment==.
replace intreatment = . if total_us_attacks==.


*gen counter after first attack
tsspell, cond(intime == 1)
drop _spell _end
rename _seq incounter
	
	
	
	
	
	
	
	
	
	
	
	
	
**********
*MODEL 12
**********	

*lethality model	
nbreg FATALITIES  intime incounter  l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.FATALITIES  ,  irr robust cl(torg)		

		*export model
		#delimit;
		outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab3-M12.xls", 
				e(N r2 adjr2  df_r) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se)    
				eform
				bdec(4) 
				sdec(4) 
				excel 
				replace;
	
	
**********
*MODEL 13
**********	 
	
*lethality model, sans IRQ and AFG	
nbreg FATALITIES  intime incounter  l1.lnustroops l1.tpaid l1.usaid lag_fdstate l1.lngdp  l1.RELI l1.LEFT l1.SEPA l1.TERRCNTRL    l1.COUNT_ALLIES l1.COUNT_RIVALS exports1 imports1 mcdonalds_time l1.FATALITIES  if hbccode !=700 & hbccode !=645,  irr robust cl(torg)		

		*export model
		#delimit;
		outreg2 using "C:\Users\chris\OneDrive\Desktop\Results\Chapter6-Tab3-M13.xls", 
				e(N r2 adjr2  df_r) 
				alpha(0.001, 0.01, 0.05, 0.1) 
				symbol(***, **, *, +) stats(coef se)    
				eform
				bdec(4) 
				sdec(4) 
				excel 
				replace;
	

	
	
	

	

****************************************
****************************************
* ZINB MODELS FOR APPENDIX
****************************************
****************************************		
	
*gen lag fatalities
by torg (year): gen lag_FATALITIES = FATALITIES[_n-1]


****************
* MODEL 8
****************

*repeat Model 8
zinb FATALITIES  time counter lag_lnustroops lag_tpaid lag_usaid lag_fdstate  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time lag_FATALITIES   , inflate(lngdp ) irr robust cl(torg)
	
	
	outreg2  using "Chapter6ZINBModel8",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, 		*, +) bdec(4) sdec(4) word replace
	
	
	
****************
* MODEL 9
****************
	
*repeat Model 9
zinb FATALITIES  time counter lag_lnustroops lag_tpaid lag_usaid lag_fdstate   lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time lag_FATALITIES  if hbccode !=700 & hbccode !=645   , inflate(lngdp ) irr robust cl(torg)
	
	outreg2  using "Chapter6ZINBModel9",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, 		*, +) bdec(4) sdec(4) word replace
	
	
	
	
****************
* MODEL 10
****************
	
*repeat Model 10
zinb FATALITIES  outtime outcounter lag_lnustroops lag_tpaid lag_usaid lag_fdstate  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time lag_FATALITIES  ,  inflate(lngdp ) irr robust cl(torg)

	
	outreg2  using "Chapter6ZINBModel10",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, 		*, +) bdec(4) sdec(4) word replace
	
	
	
	
****************
* MODEL 11
****************
	
*repeat Model 11		
zinb FATALITIES  outtime outcounter lag_lnustroops lag_tpaid lag_usaid lag_fdstate   lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time lag_FATALITIES  if hbccode !=700 & hbccode !=645 ,   inflate(lngdp ) irr robust cl(torg)	

	
	outreg2  using "Chapter6ZINBModel11",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, 		*, +) bdec(4) sdec(4) word replace
	
	
	
	
****************
* MODEL 12
****************
	
*repeat Model 12		
zinb FATALITIES  intime incounter  lag_lnustroops lag_tpaid lag_usaid lag_fdstate  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time lag_FATALITIES  ,  inflate(lngdp ) irr robust cl(torg)		

	
	outreg2  using "Chapter6ZINBModel12",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, 		*, +) bdec(4) sdec(4) word replace
	
	
	
	
	
	
	
****************
* MODEL 13
****************
	
*repeat Model 13	
zinb FATALITIES  intime incounter  lag_lnustroops lag_tpaid lag_usaid lag_fdstate  lag_RELI lag_LEFT lag_SEPA lag_TERRCNTRL    lag_COUNT_ALLIES lag_COUNT_RIVALS exports1 imports1 mcdonalds_time lag_FATALITIES  if hbccode !=700 & hbccode !=645,   inflate(lngdp )  irr robust cl(torg)		

	
	outreg2  using "Chapter6ZINBModel13",  alpha(0.001, 0.01, 0.05, 0.1)  e(chi2 ll) symbol(***, **, 		*, +) bdec(4) sdec(4) word replace
	
	
	
	
	