**********************************************************************************************
**********************************************************************************************
**********************************************************************************************
* DOMESTIC CORRELATES OF BORDER BARRIER CONSTRUCTION
**********************************************************************************************
**********************************************************************************************
**********************************************************************************************


cd "~\Dropbox\Border Projects\Data"

use "domesticcorrelates.dta", clear

*declare panel data
xtset ccode year

*create wall onset
gen wall_start = 0
replace wall_start = 1 if (construction_start == year)

*insert zeros to wall 
replace wall = 0 if wall==.

*gen combined civil and nonstate conflict
gen allconflict2 = 0
replace allconflict2=. if year > 2020
replace allconflict2 = . if year < 1989
replace allconflict2 = 1 if ucdpongoing2==1
replace allconflict2 =1 if nonstateconflict_gwcode2==1


*gen rightwing from vparty
gen rightwing_vparty = 1 if hog_party_lr_ord_vdem =="Right"
replace rightwing_vparty = 1 if hog_party_lr_ord_vdem == "Center-right"
replace rightwing_vparty = 0 if rightwing_vparty==.
replace rightwing_vparty = . if hog_party_lr_ord_vdem =="No data"

*replace missing migration
replace migrantstockpercent = 0 if migrantstockpercent==.

*rename ongoing wall
rename wall ongoing_wall

gen post911 = 1 if year > 2001
replace post = 0 if post ==.

*log continuous variables
gen lnmigrantstock = ln(migrantstockpercent+1)
gen lnunemployment = ln(unemployment_ILO_wdi) 
gen lnpop = ln(pop_wdi)
gen lngdppc = ln(gdppc_wdi)
gen lnmiddleclass = ln(share_middleclass_occupation+1)
gen lnmilitary = ln(share_military+1)
gen lnbluecollar = ln(share_bluecollar+1)
bysort ccode (year): carryforward v2elvotlrg, replace












**********************************************************************************************
*MODEL 1*************************MODEL OF WALL START WITHOUT CONTROLS
**********************************************************************************************

*gen cubic splines;
#delimit;
btscs wall_start year ccode, g(peaceyears) nspline(3);
gen peaceyears2 = peaceyears*peaceyears;
gen peaceyears3 = peaceyears*peaceyears*peaceyears;
drop _spline*;


*Model;
#delimit;
logit wall_start rightwing_vparty   peaceyears* if year > 1989, robust cl(ccode);
		*export model;
		#delimit;
		outreg2 using "Model1-oct23.doc", 
		alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
		e(all) word  replace;

		*sample ID
		gen sample1 = e(sample);
		
		*substantive effects
		listcoef, percent help 
		


**********************************************************************************************
*MODEL 2*************************MODEL OF WALL START INCLUDING CONTROLS
**********************************************************************************************


*Model;
#delimit;
logit wall_start rightwing_vparty   v2x_libdem  lnpop lngdppc lnmigrantstock   peaceyears* if year > 1989, robust cl(ccode);
		*export model;
		#delimit;
		outreg2 using "Model2-oct23.doc", 
		alpha(0.001, 0.01, 0.05, 0.1) symbol(***, **, *, +) bdec(2) sdec(2)
		e(all) word  replace;

		*sample ID
		gen sample2 = e(sample);
		
		*substantive effects
		listcoef, percent help ;
		
*clear data	
#delimit;
drop peaceyears* _spline* ;


	
	
	
	
	
	
	